import CreateForm from './create-form'

export default function CarouselCreate() {
   return (
      <div>
         <h3 className="text-xl font-bold mb-4">Create carousel item</h3>
         <CreateForm />
      </div>
   )
}
