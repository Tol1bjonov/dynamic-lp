export default function FooterManagement() {
   return <div>Footer Management</div>
}
