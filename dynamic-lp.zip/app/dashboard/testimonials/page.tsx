export default function TestimonialsManagement() {
   return <div>Testimonials Management</div>
}
