export default function FAQsManagement() {
   return <div>FAQs Management</div>
}
