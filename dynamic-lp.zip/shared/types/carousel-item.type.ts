export type CarouselItem = {
   id: number
   created_at: string
   title: string
   description: string
   text: string
   cta_link: string
}
